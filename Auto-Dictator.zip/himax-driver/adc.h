/*
 * adc.h
 *
 *  Created on: Nov 29, 2017
 *      Author: Vickram Gidwani
 */

#ifndef ADC_H_
#define ADC_H_

#include <stdio.h>
#include <stdint.h>
#include <msp430.h>
#include "driverlib.h"

void adc_init();

#endif /* ADC_H_ */
