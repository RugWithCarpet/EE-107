/*
 * dma.h
 *
 *  Created on: Dec 2, 2017
 *      Author: Vickram Gidwani
 */

#ifndef DMA2_H_
#define DMA2_H_

#include <stdio.h>
#include <stdint.h>
#include <msp430.h>
#include "driverlib.h"

void dma_init();

#endif /* DMA2_H_ */
